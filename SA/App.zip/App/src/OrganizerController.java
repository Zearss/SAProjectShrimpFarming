import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URISyntaxException;

public class OrganizerController {
    @FXML
    ImageView image;
    @FXML
    Pane scenePane;
    @FXML
    public void initialize() throws URISyntaxException{
//        image.setImage(new Image(getClass().getResource("jung.jpg").toURI().toString()));
        scenePane.setStyle("-fx-background-color: Pink");
    }
    @FXML
    public void manuBtnAction(ActionEvent event) throws IOException{
        Button b = (Button) event.getSource();
        Stage stage = (Stage) b.getScene().getWindow();
        FXMLLoader loader = new FXMLLoader(getClass().getResource("manu.fxml"));
        stage.setScene(new Scene(loader.load(),600,400));
        stage.show();
    }
}
