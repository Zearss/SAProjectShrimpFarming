import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URISyntaxException;

public class SizeController {
    @FXML
    Pane scenePane;
    @FXML
    public void initialize() throws URISyntaxException {
        scenePane.setStyle("-fx-background-color: Pink");
    }
    @FXML
    public void endBtnAction(ActionEvent event) throws IOException {
        Button b = (Button) event.getSource();
        Stage stage = (Stage) b.getScene().getWindow();
        FXMLLoader loader = new FXMLLoader(getClass().getResource("end.fxml"));
        stage.setScene(new Scene(loader.load(),600,400));
        stage.show();
    }
}
